# Object-Detection-using-LiDAR

This repo refers to object detection using LiDAR data specifically LAS and LAZ formats.

Libraries used: 

    1. laspy
    
    2. Keras
    
    3. tensorflow
    
    4. numpy
    
    5. scipy
    
    6. pcl
    
Algorithm glimpse:
Used tensorflow to detect object using point cloud all 3d models will be marked and objects around sensors are detected
1.las file is converted to pcd
2.pcd is passed to pointcloudvisualizer in tensorflow
3.all detected objects are shown.







