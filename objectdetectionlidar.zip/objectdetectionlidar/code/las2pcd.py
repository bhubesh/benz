


from laspy.file import File
import numpy as np

inFile = File('one.las', mode='r')

I = inFile.Classification == 2

outFile = File('2.pcd', mode='w', header=inFile.header)
outFile.points = inFile.points[I]
outFile.close()
